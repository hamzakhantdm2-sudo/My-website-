# Khata AI — production integration scaffold

This is a **real-integration application scaffold**, not a fake demo. It has no hardcoded OTP, demo customer data, simulated chat composer, or browser-only sign-in. It includes:

- Browser frontend with light/dark theme and English/Urdu RTL toggle.
- Real Twilio Verify API request/check using WhatsApp channel.
- HttpOnly signed session cookie; rate-limited auth endpoints.
- PostgreSQL merchants, customers, ledger entries, inbound/outbound WhatsApp messages and audit log.
- Twilio WhatsApp webhook with request-signature validation and inbound-message idempotency.
- OpenAI Responses API for ledger-grounded reply generation; OpenAI audio transcription for incoming Twilio-hosted audio media.
- Guardrail that replaces likely bank/payment-account details with a safe instruction to call or visit the shop.
- Append-only DB triggers blocking UPDATE/DELETE for audit logs and WhatsApp message records. No delete routes/UI exist.

## Important before production

This code does **not** make the service live by itself. You must configure a real Twilio account, WhatsApp-enabled sender, Twilio Verify service with WhatsApp enabled, OpenAI API key, PostgreSQL database, HTTPS hosting, and webhook URL. Meta/Twilio business and template/WhatsApp policy approvals may apply. No credentials are included in this archive.

The response persona transparently identifies as the automated support assistant for the merchant; it does not impersonate a human owner. The application does not share bank account details in chat. Never test with real customer data until access control, privacy terms, backups, retention, legal obligations and incident response have been reviewed.

## Requirements

- Node.js 20+
- PostgreSQL 14+ (or a managed PostgreSQL service)
- Twilio account with Verify WhatsApp channel configured, and a Twilio WhatsApp sender
- OpenAI API access for Responses and audio transcription
- Public HTTPS deployment with a stable URL for Twilio webhook signature validation

## 1. Database

Create a database, then run:

```sh
psql "$DATABASE_URL" -f sql/schema.sql
```

Use a dedicated database role for the application, not a superuser. For stronger tamper resistance, restrict table privileges for `audit_logs` and `whatsapp_messages`, take immutable/offsite backups, and alert on privileged schema/role changes. The triggers in this starter prevent ordinary UPDATE/DELETE but cannot stop a database superuser from changing schema or disabling triggers.

## 2. Configure environment

```sh
cp .env.example .env
```

Set all values in `.env` from your own provider dashboards. Generate a strong secret, for example:

```sh
openssl rand -base64 48
```

Set `PUBLIC_BASE_URL` to the exact HTTPS origin of this deployment. Set `APP_ORIGIN` to the browser origin. Set `TWILIO_WHATSAPP_FROM` to the provider-configured sender in `whatsapp:+E164` format. Do not put secrets in `public/index.html`, Git, screenshots, or messages.

## 3. Install and run

```sh
npm install
npm start
```

Open the app at your deployment URL. In production the server exits if required secrets are missing. Health check: `/healthz`.

## 4. Twilio configuration

- Configure the Verify Service to support the WhatsApp channel and required templates/approval.
- Configure the WhatsApp sender with Twilio.
- Set the inbound message webhook to `https://YOUR_DOMAIN/webhooks/twilio/whatsapp`.
- `PUBLIC_BASE_URL` must match the externally visible URL used for Twilio signature validation, including path/query as Twilio sends it.
- The signed-in merchant must save the connected WhatsApp sender number under **WhatsApp setup**. Incoming messages to that sender are mapped to the merchant.

The OTP verifies the number supplied at sign-in. The separate connected sender number is the number that receives customer messages through the Twilio webhook. They may be different.

## 5. Data flow

1. `/api/auth/otp/start` calls Twilio Verify `verifications.create({ channel: 'whatsapp' })`.
2. `/api/auth/otp/verify` calls Twilio Verify `verificationChecks.create`, then creates/updates the merchant and sets an HttpOnly session cookie.
3. The signed Twilio webhook stores inbound messages, maps the recipient sender to a merchant and the sender phone to a customer, fetches ledger rows from PostgreSQL, generates a grounded reply, sends it via Twilio, and stores the outbound message plus audit event.
4. Voice media from Twilio is downloaded only from `api.twilio.com`, capped at 20 MB, and transcribed through OpenAI before reply generation.
5. No API route deletes messages or audit events.

## Production hardening still recommended

- Put the service behind HTTPS and a WAF; configure strict `APP_ORIGIN`, cookie settings and a proper secrets manager.
- Add CSRF tokens for any future cross-origin/browser state-changing use, stronger phone normalization with `libphonenumber-js`, user/team roles, company onboarding review and account recovery controls.
- Add a queue (e.g. BullMQ/SQS) for webhook processing, retries and provider status callbacks; store media consent and retention policy.
- Add database row-level security or rigorously reviewed tenant filters for every query; automated tenant-isolation tests are essential.
- Review applicable WhatsApp opt-in/template/24-hour window rules and local privacy/debt-collection laws before messaging customers.
- Use a dedicated DB role with minimal grants; database triggers alone are not cryptographic immutability.
- Add tests, monitoring, error reporting, rate-limit storage shared across replicas, backups and disaster recovery.
- Add a merchant-confirmation step before automatically sending messages about disputed invoices or payment commitments.

## API endpoints

- `POST /api/auth/otp/start`
- `POST /api/auth/otp/verify`
- `POST /api/auth/logout`
- `GET /api/me`
- `GET /api/customers`, `POST /api/customers`
- `POST /api/ledger/entries`
- `GET /api/messages`
- `GET /api/audit-logs`
- `POST /api/settings/whatsapp-sender`
- `POST /webhooks/twilio/whatsapp` (Twilio-signed webhook only)
