require('dotenv').config();
const express = require('express');
const helmet = require('helmet');
const cookieParser = require('cookie-parser');
const rateLimit = require('express-rate-limit');
const jwt = require('jsonwebtoken');
const { Pool } = require('pg');
const twilio = require('twilio');
const path = require('path');

const required = ['DATABASE_URL','SESSION_SECRET','TWILIO_ACCOUNT_SID','TWILIO_AUTH_TOKEN','TWILIO_VERIFY_SERVICE_SID','TWILIO_WHATSAPP_FROM','OPENAI_API_KEY','PUBLIC_BASE_URL'];
const missing = required.filter(k => !process.env[k]);
if (process.env.NODE_ENV === 'production' && missing.length) {
  console.error(`Missing required production environment variables: ${missing.join(', ')}`);
  process.exit(1);
}
if ((process.env.SESSION_SECRET || '').length < 32 && process.env.NODE_ENV === 'production') {
  console.error('SESSION_SECRET must be at least 32 characters.'); process.exit(1);
}

const app = express();
const isProd = process.env.NODE_ENV === 'production';
const pool = new Pool({ connectionString: process.env.DATABASE_URL, ssl: process.env.DATABASE_SSL === 'false' ? false : (isProd ? { rejectUnauthorized: true } : undefined) });
const twilioClient = twilio(process.env.TWILIO_ACCOUNT_SID, process.env.TWILIO_AUTH_TOKEN);
const verifyLimiter = rateLimit({ windowMs: 15 * 60 * 1000, limit: 5, standardHeaders: true, legacyHeaders: false, message: { error: 'Too many verification attempts. Try again later.' } });
const apiLimiter = rateLimit({ windowMs: 60 * 1000, limit: 120, standardHeaders: true, legacyHeaders: false });

app.set('trust proxy', 1);
app.use(helmet({ contentSecurityPolicy: false }));
app.use(cookieParser());
// Twilio webhooks require application/x-www-form-urlencoded; this parser also supplies the fields for signature validation.
app.use('/webhooks/twilio/whatsapp', express.urlencoded({ extended: false, limit: '64kb' }));
app.use(express.json({ limit: '1mb' }));
app.use(apiLimiter);

function checkOrigin(req, res, next) {
  const expected = process.env.APP_ORIGIN;
  const origin = req.get('origin');
  if (expected && origin && origin !== expected) return res.status(403).json({ error: 'Origin not allowed.' });
  next();
}
app.use('/api', checkOrigin);
function normalizePhone(value) {
  if (typeof value !== 'string') return null;
  const phone = value.trim().replace(/^whatsapp:/i, '').replace(/[\s().-]/g, '');
  return /^\+[1-9]\d{7,14}$/.test(phone) ? phone : null;
}
function requireAuth(req, res, next) {
  const token = req.cookies?.khata_session;
  if (!token) return res.status(401).json({ error: 'Sign in required.' });
  try { req.auth = jwt.verify(token, process.env.SESSION_SECRET); next(); }
  catch { res.clearCookie('khata_session', cookieOptions()); return res.status(401).json({ error: 'Session expired. Please sign in again.' }); }
}
function cookieOptions() { return { httpOnly: true, secure: isProd, sameSite: 'strict', path: '/', maxAge: 8 * 60 * 60 * 1000 }; }
async function audit(merchantId, eventType, actorType, actorRef, details = {}) {
  await pool.query('INSERT INTO audit_logs(merchant_id,event_type,actor_type,actor_ref,details) VALUES($1,$2,$3,$4,$5)', [merchantId || null, eventType, actorType, actorRef || null, JSON.stringify(details)]);
}
function twilioSignatureValid(req) {
  const signature = req.get('x-twilio-signature');
  if (!signature || !process.env.TWILIO_AUTH_TOKEN) return false;
  const url = `${process.env.PUBLIC_BASE_URL.replace(/\/$/, '')}${req.originalUrl}`;
  return twilio.validateRequest(process.env.TWILIO_AUTH_TOKEN, signature, url, req.body || {});
}

app.get('/healthz', (_req, res) => res.json({ ok: true }));

// Real Twilio Verify API: no local/static OTP fallback exists.
app.post('/api/auth/otp/start', verifyLimiter, async (req, res) => {
  const companyName = String(req.body?.companyName || '').trim();
  const phone = normalizePhone(req.body?.whatsappNumber);
  if (companyName.length < 2 || companyName.length > 160 || !phone) return res.status(400).json({ error: 'Enter a company name and WhatsApp number in international format, e.g. +923001234567.' });
  try {
    const result = await twilioClient.verify.v2.services(process.env.TWILIO_VERIFY_SERVICE_SID).verifications.create({ to: phone, channel: 'whatsapp' });
    await audit(null, 'otp_requested', 'system', phone, { channel: 'whatsapp', providerStatus: result.status });
    res.json({ ok: true, status: result.status, message: 'If this number is eligible and your Twilio Verify WhatsApp setup is approved, a real verification code will be sent.' });
  } catch (e) {
    console.error('OTP start failed', e.code || e.message);
    res.status(502).json({ error: 'WhatsApp verification could not be started. Check Twilio Verify setup and number eligibility.' });
  }
});

app.post('/api/auth/otp/verify', verifyLimiter, async (req, res) => {
  const companyName = String(req.body?.companyName || '').trim();
  const phone = normalizePhone(req.body?.whatsappNumber);
  const code = String(req.body?.code || '').trim();
  if (companyName.length < 2 || companyName.length > 160 || !phone || !/^\d{6}$/.test(code)) return res.status(400).json({ error: 'Enter the same company name and number, plus the six-digit code.' });
  try {
    const check = await twilioClient.verify.v2.services(process.env.TWILIO_VERIFY_SERVICE_SID).verificationChecks.create({ to: phone, code });
    if (check.status !== 'approved') return res.status(401).json({ error: 'The code was not approved. Request a new code if it expired.' });
    const { rows } = await pool.query(
      `INSERT INTO merchants(company_name,login_whatsapp_number) VALUES($1,$2)
       ON CONFLICT(login_whatsapp_number) DO UPDATE SET company_name=EXCLUDED.company_name, updated_at=now()
       RETURNING id, company_name, login_whatsapp_number, whatsapp_sender_number`, [companyName, phone]);
    const merchant = rows[0];
    const token = jwt.sign({ sub: merchant.id }, process.env.SESSION_SECRET, { expiresIn: '8h', issuer: 'khata-ai' });
    res.cookie('khata_session', token, cookieOptions());
    await audit(merchant.id, 'merchant_signed_in', 'merchant', phone, { provider: 'twilio_verify' });
    res.json({ ok: true, merchant });
  } catch (e) {
    console.error('OTP verify failed', e.code || e.message);
    res.status(502).json({ error: 'Verification service could not complete the check. Please try again.' });
  }
});
app.post('/api/auth/logout', requireAuth, async (req, res) => {
  await audit(req.auth.sub, 'merchant_signed_out', 'merchant', req.auth.sub, {});
  res.clearCookie('khata_session', cookieOptions()); res.json({ ok: true });
});
app.get('/api/me', requireAuth, async (req, res) => {
  const { rows } = await pool.query('SELECT id,company_name,login_whatsapp_number,whatsapp_sender_number,created_at FROM merchants WHERE id=$1', [req.auth.sub]);
  if (!rows[0]) return res.status(401).json({ error: 'Account not found.' });
  res.json({ merchant: rows[0] });
});

app.post('/api/settings/whatsapp-sender', requireAuth, async (req, res) => {
  const sender = normalizePhone(req.body?.whatsappSenderNumber);
  if (!sender) return res.status(400).json({ error: 'Enter the connected WhatsApp sender number in international format.' });
  try {
    const { rows } = await pool.query('UPDATE merchants SET whatsapp_sender_number=$1,updated_at=now() WHERE id=$2 RETURNING id,company_name,login_whatsapp_number,whatsapp_sender_number', [sender, req.auth.sub]);
    await audit(req.auth.sub, 'whatsapp_sender_configured', 'merchant', req.auth.sub, { sender });
    res.json({ merchant: rows[0] });
  } catch (e) {
    if (e.code === '23505') return res.status(409).json({ error: 'This WhatsApp sender is already linked to another merchant.' });
    console.error(e); res.status(500).json({ error: 'Could not save WhatsApp sender.' });
  }
});

app.get('/api/customers', requireAuth, async (req, res) => {
  const { rows } = await pool.query(
    `SELECT c.id,c.customer_name,c.whatsapp_number,c.created_at,
      COALESCE(SUM(CASE WHEN l.entry_type IN ('debit','adjustment') THEN l.amount WHEN l.entry_type IN ('credit','payment') THEN -l.amount ELSE 0 END),0)::numeric(14,2) AS balance,
      MAX(l.promise_date) FILTER (WHERE l.promise_date IS NOT NULL) AS promise_date
     FROM customers c LEFT JOIN ledger_entries l ON l.customer_id=c.id AND l.merchant_id=c.merchant_id
     WHERE c.merchant_id=$1 GROUP BY c.id ORDER BY c.customer_name`, [req.auth.sub]);
  res.json({ customers: rows });
});
app.post('/api/customers', requireAuth, async (req, res) => {
  const name = String(req.body?.customerName || '').trim();
  const phone = normalizePhone(req.body?.whatsappNumber);
  const amount = Number(req.body?.pendingAmount);
  const date = req.body?.purchaseDate || null;
  const promiseDate = req.body?.promiseDate || null;
  const description = String(req.body?.itemDetails || '').trim();
  if (!name || name.length > 160 || !phone || !Number.isFinite(amount) || amount < 0 || amount > 1e12 || !description || description.length > 500) return res.status(400).json({ error: 'Enter valid customer name, international WhatsApp number, amount and item details.' });
  const client = await pool.connect();
  try {
    await client.query('BEGIN');
    const c = await client.query('INSERT INTO customers(merchant_id,customer_name,whatsapp_number) VALUES($1,$2,$3) RETURNING *', [req.auth.sub, name, phone]);
    if (amount > 0) await client.query(`INSERT INTO ledger_entries(merchant_id,customer_id,entry_type,amount,description,invoice_date,promise_date) VALUES($1,$2,'debit',$3,$4,$5,$6)`, [req.auth.sub, c.rows[0].id, amount, description, date, promiseDate]);
    await client.query('INSERT INTO audit_logs(merchant_id,event_type,actor_type,actor_ref,details) VALUES($1,$2,$3,$4,$5)', [req.auth.sub, 'customer_created', 'merchant', req.auth.sub, JSON.stringify({ customerId: c.rows[0].id, customerName: name, initialAmount: amount })]);
    await client.query('COMMIT'); res.status(201).json({ customer: c.rows[0] });
  } catch (e) {
    await client.query('ROLLBACK');
    if (e.code === '23505') return res.status(409).json({ error: 'A customer with this WhatsApp number already exists.' });
    console.error(e); res.status(500).json({ error: 'Could not save customer.' });
  } finally { client.release(); }
});
app.post('/api/ledger/entries', requireAuth, async (req, res) => {
  const customerId = String(req.body?.customerId || '');
  const type = String(req.body?.entryType || 'debit');
  const amount = Number(req.body?.amount);
  const description = String(req.body?.description || '').trim();
  const invoiceDate = req.body?.invoiceDate || null;
  const promiseDate = req.body?.promiseDate || null;
  if (!/^[0-9a-f-]{36}$/i.test(customerId) || !['debit','credit','payment','adjustment'].includes(type) || !Number.isFinite(amount) || amount < 0 || amount > 1e12 || !description || description.length > 500) return res.status(400).json({ error: 'Invalid ledger entry.' });
  const { rows: c } = await pool.query('SELECT id FROM customers WHERE id=$1 AND merchant_id=$2', [customerId, req.auth.sub]);
  if (!c[0]) return res.status(404).json({ error: 'Customer not found.' });
  const { rows } = await pool.query('INSERT INTO ledger_entries(merchant_id,customer_id,entry_type,amount,description,invoice_date,promise_date) VALUES($1,$2,$3,$4,$5,$6,$7) RETURNING *', [req.auth.sub, customerId, type, amount, description, invoiceDate, promiseDate]);
  await audit(req.auth.sub, 'ledger_entry_created', 'merchant', req.auth.sub, { ledgerEntryId: rows[0].id, customerId, type, amount });
  res.status(201).json({ entry: rows[0] });
});
app.get('/api/audit-logs', requireAuth, async (req, res) => {
  const limit = Math.min(200, Math.max(1, Number(req.query.limit) || 100));
  const { rows } = await pool.query('SELECT id,event_type,actor_type,actor_ref,details,created_at FROM audit_logs WHERE merchant_id=$1 ORDER BY id DESC LIMIT $2', [req.auth.sub, limit]);
  res.json({ logs: rows });
});
app.get('/api/messages', requireAuth, async (req, res) => {
  const { rows } = await pool.query('SELECT id,customer_id,direction,from_number,to_number,body,status,created_at FROM whatsapp_messages WHERE merchant_id=$1 ORDER BY id DESC LIMIT 200', [req.auth.sub]);
  res.json({ messages: rows });
});

function safeNoBankDetails(text) {
  const s = String(text || '');
  // If a model ever produces a long digit sequence or a payment-account phrase, replace the entire message.
  const accountLike = /\b(?:bank account|account number|iban|upi id|easypaisa|jazzcash|routing number|sort code)\b/i.test(s) || /(?:\+?\d[\d\s-]{9,}\d)/.test(s);
  if (accountLike) return 'For your safety, please call or visit the shop directly to confirm payment methods. We do not share payment account details in WhatsApp chat.';
  return s;
}
async function transcribeTwilioAudio(mediaUrl, contentType) {
  if (!mediaUrl || !contentType || !String(contentType).toLowerCase().startsWith('audio/')) return null;
  const parsed = new URL(mediaUrl);
  if (parsed.protocol !== 'https:' || parsed.hostname !== 'api.twilio.com') throw new Error('Unexpected Twilio media host');
  const basic = Buffer.from(`${process.env.TWILIO_ACCOUNT_SID}:${process.env.TWILIO_AUTH_TOKEN}`).toString('base64');
  const mediaResponse = await fetch(mediaUrl, { headers: { Authorization: `Basic ${basic}` } });
  if (!mediaResponse.ok) throw new Error(`Twilio media download failed: ${mediaResponse.status}`);
  const buffer = Buffer.from(await mediaResponse.arrayBuffer());
  if (!buffer.length || buffer.length > 20 * 1024 * 1024) throw new Error('Voice note is empty or exceeds the 20 MB limit');
  const form = new FormData();
  form.append('model', 'gpt-4o-mini-transcribe');
  form.append('file', new Blob([buffer], { type: contentType }), 'voice-note');
  const transcriptionResponse = await fetch('https://api.openai.com/v1/audio/transcriptions', {
    method: 'POST', headers: { Authorization: `Bearer ${process.env.OPENAI_API_KEY}` }, body: form
  });
  if (!transcriptionResponse.ok) throw new Error(`Audio transcription failed: ${transcriptionResponse.status}`);
  const result = await transcriptionResponse.json();
  return String(result.text || '').trim() || null;
}

async function generateLedgerReply(companyName, customerName, entries, inboundText) {
  const ledgerSummary = entries.length ? entries.map(e => `${e.invoice_date ? `Invoice date ${e.invoice_date}; ` : ''}${e.entry_type} ${e.currency} ${e.amount}; item/description: ${e.description}${e.promise_date ? `; promised date ${e.promise_date}` : ''}`).join('\n') : 'No ledger entries were found for this customer.';
  const balance = entries.reduce((sum,e) => sum + (['debit','adjustment'].includes(e.entry_type) ? Number(e.amount) : -Number(e.amount)), 0);
  const prompt = `You are the customer-support messaging assistant for ${companyName}. Be polite and concise in the language the customer uses (Urdu or English). Identify transparently as the automated assistant for ${companyName}; do not claim to be a human owner. Only state facts from the ledger context. Never invent invoice dates, item prices, payment records or balances. Never reveal bank account numbers, IBANs, UPI IDs, EasyPaisa/JazzCash details, or payment credentials. If asked how to pay, direct the customer to call or visit the shop. If ledger data is missing or the question needs human judgment, say the shop team will confirm. Do not threaten or harass. Customer name: ${customerName}. Calculated current balance: PKR ${balance.toFixed(2)}. Ledger rows:\n${ledgerSummary}\nCustomer message: ${inboundText}`;
  const response = await fetch('https://api.openai.com/v1/responses', {
    method: 'POST', headers: { 'Authorization': `Bearer ${process.env.OPENAI_API_KEY}`, 'Content-Type': 'application/json' },
    body: JSON.stringify({ model: process.env.OPENAI_MODEL || 'gpt-4.1-mini', input: prompt, max_output_tokens: 250 })
  });
  if (!response.ok) throw new Error(`OpenAI response status ${response.status}`);
  const data = await response.json();
  const text = data.output?.flatMap(item => item.content || []).filter(c => c.type === 'output_text').map(c => c.text).join('\n').trim();
  if (!text) throw new Error('Empty AI response');
  return safeNoBankDetails(text);
}

app.post('/webhooks/twilio/whatsapp', async (req, res) => {
  if (!twilioSignatureValid(req)) return res.status(403).send('Invalid Twilio signature');
  const from = normalizePhone(req.body?.From);
  const to = normalizePhone(req.body?.To);
  const body = String(req.body?.Body || '').slice(0, 4000);
  const sid = String(req.body?.MessageSid || '');
  if (!from || !to || !sid) return res.status(400).send('Invalid webhook payload');
  let client;
  try {
    client = await pool.connect();
    await client.query('BEGIN');
    const { rows: mrows } = await client.query('SELECT id,company_name,whatsapp_sender_number FROM merchants WHERE whatsapp_sender_number=$1', [to]);
    const merchant = mrows[0];
    if (!merchant) { await client.query('ROLLBACK'); return res.status(200).type('text/xml').send('<Response></Response>'); }
    const ins = await client.query(`INSERT INTO whatsapp_messages(merchant_id,provider_message_sid,direction,from_number,to_number,body,media_content_type,media_url,status)
      VALUES($1,$2,'inbound',$3,$4,$5,$6,$7,'received') ON CONFLICT(provider_message_sid) DO NOTHING RETURNING id`,
      [merchant.id, sid, from, to, body, req.body?.MediaContentType0 || null, req.body?.MediaUrl0 || null]);
    if (!ins.rows[0]) { await client.query('COMMIT'); return res.status(200).type('text/xml').send('<Response></Response>'); }
    const { rows: customers } = await client.query('SELECT id,customer_name FROM customers WHERE merchant_id=$1 AND whatsapp_number=$2', [merchant.id, from]);
    const customer = customers[0];
    const { rows: logs } = await client.query('INSERT INTO audit_logs(merchant_id,event_type,actor_type,actor_ref,details) VALUES($1,$2,$3,$4,$5) RETURNING id', [merchant.id, 'whatsapp_message_received', 'webhook', from, JSON.stringify({ messageSid: sid, customerId: customer?.id || null })]);
    const { rows: entries } = customer ? await client.query(`SELECT entry_type,amount,currency,description,invoice_date::text,promise_date::text FROM ledger_entries WHERE merchant_id=$1 AND customer_id=$2 ORDER BY created_at DESC LIMIT 50`, [merchant.id, customer.id]) : { rows: [] };
    await client.query('COMMIT');
    let reply;
    let customerMessageText = body;
    if (!body && req.body?.MediaUrl0 && String(req.body?.MediaContentType0 || '').toLowerCase().startsWith('audio/')) {
      try { customerMessageText = await transcribeTwilioAudio(req.body.MediaUrl0, req.body.MediaContentType0) || '[Customer sent an audio note that could not be transcribed.]'; }
      catch (e) { console.error('Voice transcription failed', e.message); customerMessageText = '[Customer sent an audio note; transcription failed. Please ask the shop team to review it.]'; }
      await audit(merchant.id, 'whatsapp_voice_note_processed', 'system', 'khata-ai', { inboundSid: sid, transcribed: !customerMessageText.startsWith('[Customer sent') });
    }
    if (!customer) reply = `Assalam-o-Alaikum. This is the automated support assistant for ${merchant.company_name}. We could not match this WhatsApp number to a customer record. Please contact or visit the shop so the team can help.`;
    else {
      try { reply = await generateLedgerReply(merchant.company_name, customer.customer_name, entries, customerMessageText || '[Customer sent media without text.]'); }
      catch (e) { console.error('AI reply generation failed', e.message); reply = `Assalam-o-Alaikum. This is the automated support assistant for ${merchant.company_name}. We received your message, but the team needs to confirm the details. Please contact or visit the shop.`; }
    }
    reply = safeNoBankDetails(reply);
    const sent = await twilioClient.messages.create({ from: `whatsapp:${to}`, to: `whatsapp:${from}`, body: reply });
    await pool.query(`INSERT INTO whatsapp_messages(merchant_id,customer_id,provider_message_sid,direction,from_number,to_number,body,status) VALUES($1,$2,$3,'outbound',$4,$5,$6,'sent') ON CONFLICT(provider_message_sid) DO NOTHING`, [merchant.id, customer?.id || null, sent.sid, to, from, reply]);
    await audit(merchant.id, 'whatsapp_reply_sent', 'system', 'khata-ai', { messageSid: sent.sid, inboundSid: sid, customerId: customer?.id || null });
    res.status(200).type('text/xml').send('<Response></Response>');
  } catch (e) {
    if (client) { try { await client.query('ROLLBACK'); } catch {} }
    console.error('WhatsApp webhook failed', e.message);
    // Twilio can retry on non-2xx. Idempotency key prevents duplicate inbound rows.
    res.status(500).send('Webhook processing failed');
  } finally { client?.release(); }
});

app.use(express.static(path.join(__dirname, '..', 'public'), { index: 'index.html', etag: true, maxAge: isProd ? '1h' : 0 }));
app.use((err, _req, res, _next) => { console.error(err); res.status(500).json({ error: 'Internal server error.' }); });
const port = Number(process.env.PORT || 3000);
app.listen(port, () => console.log(`Khata AI server listening on ${port}`));
