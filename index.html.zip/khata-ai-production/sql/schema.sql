BEGIN;
CREATE EXTENSION IF NOT EXISTS pgcrypto;

CREATE TABLE IF NOT EXISTS merchants (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  company_name TEXT NOT NULL CHECK (length(company_name) BETWEEN 2 AND 160),
  login_whatsapp_number TEXT NOT NULL UNIQUE,
  whatsapp_sender_number TEXT UNIQUE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS customers (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  merchant_id UUID NOT NULL REFERENCES merchants(id),
  customer_name TEXT NOT NULL CHECK (length(customer_name) BETWEEN 1 AND 160),
  whatsapp_number TEXT NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (merchant_id, whatsapp_number)
);
CREATE INDEX IF NOT EXISTS customers_merchant_phone_idx ON customers(merchant_id, whatsapp_number);

CREATE TABLE IF NOT EXISTS ledger_entries (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  merchant_id UUID NOT NULL REFERENCES merchants(id),
  customer_id UUID NOT NULL REFERENCES customers(id),
  entry_type TEXT NOT NULL CHECK (entry_type IN ('debit','credit','payment','adjustment')),
  amount NUMERIC(14,2) NOT NULL CHECK (amount >= 0),
  currency CHAR(3) NOT NULL DEFAULT 'PKR',
  description TEXT NOT NULL CHECK (length(description) BETWEEN 1 AND 500),
  invoice_date DATE,
  promise_date DATE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  created_by UUID
);
CREATE INDEX IF NOT EXISTS ledger_merchant_customer_date_idx ON ledger_entries(merchant_id, customer_id, created_at DESC);

-- Append-only event ledger. Application exposes no delete endpoint. Trigger blocks deletes even if a bug is introduced.
CREATE TABLE IF NOT EXISTS audit_logs (
  id BIGSERIAL PRIMARY KEY,
  merchant_id UUID REFERENCES merchants(id),
  event_type TEXT NOT NULL,
  actor_type TEXT NOT NULL CHECK (actor_type IN ('merchant','customer','system','webhook')),
  actor_ref TEXT,
  details JSONB NOT NULL DEFAULT '{}'::jsonb,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS audit_merchant_time_idx ON audit_logs(merchant_id, created_at DESC);

CREATE TABLE IF NOT EXISTS whatsapp_messages (
  id BIGSERIAL PRIMARY KEY,
  merchant_id UUID NOT NULL REFERENCES merchants(id),
  customer_id UUID REFERENCES customers(id),
  provider_message_sid TEXT UNIQUE,
  direction TEXT NOT NULL CHECK (direction IN ('inbound','outbound')),
  from_number TEXT NOT NULL,
  to_number TEXT NOT NULL,
  body TEXT NOT NULL DEFAULT '',
  media_content_type TEXT,
  media_url TEXT,
  status TEXT NOT NULL DEFAULT 'received',
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS wa_merchant_time_idx ON whatsapp_messages(merchant_id, created_at DESC);

CREATE OR REPLACE FUNCTION reject_immutable_delete() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
  RAISE EXCEPTION 'DELETE is disabled for immutable audit/message records';
END;
$$;
DROP TRIGGER IF EXISTS audit_logs_no_delete ON audit_logs;
CREATE TRIGGER audit_logs_no_delete BEFORE DELETE ON audit_logs FOR EACH ROW EXECUTE FUNCTION reject_immutable_delete();
DROP TRIGGER IF EXISTS whatsapp_messages_no_delete ON whatsapp_messages;
CREATE TRIGGER whatsapp_messages_no_delete BEFORE DELETE ON whatsapp_messages FOR EACH ROW EXECUTE FUNCTION reject_immutable_delete();

CREATE OR REPLACE FUNCTION reject_immutable_update() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
  RAISE EXCEPTION 'UPDATE is disabled for immutable audit/message records';
END;
$$;
DROP TRIGGER IF EXISTS audit_logs_no_update ON audit_logs;
CREATE TRIGGER audit_logs_no_update BEFORE UPDATE ON audit_logs FOR EACH ROW EXECUTE FUNCTION reject_immutable_update();
DROP TRIGGER IF EXISTS whatsapp_messages_no_update ON whatsapp_messages;
CREATE TRIGGER whatsapp_messages_no_update BEFORE UPDATE ON whatsapp_messages FOR EACH ROW EXECUTE FUNCTION reject_immutable_update();
COMMIT;
